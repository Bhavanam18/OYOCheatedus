from django.apps import AppConfig


class OyocheatedusConfig(AppConfig):
    name = 'OYOCheatedUS'
